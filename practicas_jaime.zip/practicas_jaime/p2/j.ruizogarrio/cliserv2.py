import os
import datetime
import sys

def cliente():
    print('Cliente pide:')
    print('Dime fecha y hora actual')
    os.close(pipe_servidor)

    # Esperar a recibir la respuesta del servidor
    pipe_cliente_lectura = os.fdopen(pipe_cliente, 'r')
    respuesta = pipe_cliente_lectura.read()

    print(f"El servidor responde con la fecha y hora actual: {respuesta}")
    sys.exit(0)

def servidor():
    os.close(pipe_cliente)

    ahora = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    pipe_servidor_escritura = os.fdopen(pipe_servidor, 'w')
    pipe_servidor_escritura.write(ahora)
    pipe_servidor_escritura.close()
    sys.exit(0)

if __name__ == "__main__":
    # Crear los pipes
    pipe_cliente, pipe_servidor = os.pipe()
    pid = os.fork()

    if pid > 0:
        servidor()
    else:
        cliente()

