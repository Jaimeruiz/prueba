import socket
import threading

username = input('Introduce tu nombre de usuario: ')

cliente_addr = ('localhost', 12345)

socket_cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
socket_cliente.connect(cliente_addr)

def recibir_mensaje():
    while True:
        try:
            mensaje = socket_cliente.recv(1024).decode('utf-8')
    
            if mensaje == 'Introduce tu nombre de usuario':
                socket_cliente.send(username.encode('UTF-8'))
            else:
                print(mensaje)
        except:
            print('Ha habido un error')
            socket_cliente.close()
            break

def enviar_mensaje():
    while True:
        mensaje = f"{username}: {input('')}"
        socket_cliente.send(mensaje.encode('UTF-8'))

hilo_lectura = threading.Thread(target=recibir_mensaje)
hilo_lectura.start()

hilo_escritura = threading.Thread(target=enviar_mensaje)
hilo_escritura.start()



