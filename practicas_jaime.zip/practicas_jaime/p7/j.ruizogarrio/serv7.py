import socket 
import threading

server_addr = ('localhost', 12345)

socket_servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

socket_servidor.bind(server_addr)
socket_servidor.listen(5)
print('Servidor esperando clientes')

clientes = []
usernames = []

def enviar(mensaje, emisor):    #emisor para identificar al usuario que envia el mensaje y no replicar el mensaje en su consola
    for cliente in clientes:
        if cliente != emisor:
            cliente.send(mensaje)
        

def mensajero(cliente):
    while True:

        try:
            mensaje = cliente.recv(1024)
            enviar(mensaje, cliente)
        except:
            indice_cliente = clientes.index(cliente)
            username = usernames[index]
            enviar(f'El usuario:  {usuario} se desconecto'.encode('UTF-8'))
            clientes.remove(cliente)
            usernames.remove(username)
            cliente.close()

def conexion():
    while True: 
       conn_cliente, addr = socket_servidor.accept()

       conn_cliente.send('Introduce tu nombre de usuario'.encode('UTF-8'))
       username = conn_cliente.recv(1024).decode('UTF-8')

       clientes.append(conn_cliente) 
       usernames.append(username)

       print(f"{username} se ha conectado al servidor {str(addr)}")
       mensaje = f"{username} se ha unido al char".encode('UTF-8')
       conn_cliente.send("Conectado al servidor".encode('UTF-8'))

       hilo = threading.Thread(target=mensajero, args=(conn_cliente,))
       hilo.start()

if __name__ == '__main__':
    conexion()
