import socket
import datetime
import os

socket_path = '/tmp/socket_uds'

def responder_fecha_hora():
    server_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)

    try:
        os.remove(socket_path)
    except OSError:
        pass

    server_socket.bind(socket_path)
    server_socket.listen(1)

    print("Servidor: Esperando conexión del cliente...")

    while True:
        conn, addr = server_socket.accept()
        print("Servidor: Cliente conectado:", addr)

        solicitud = conn.recv(1024).decode()

        if solicitud == "Fecha y hora, por favor":
            ahora = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            conn.send(ahora.encode())

        conn.close()

if __name__ == "__main__":
    responder_fecha_hora()

