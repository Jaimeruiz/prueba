import socket

socket_path = '/tmp/socket_uds'

def obtener_fecha_hora():
    client_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    client_socket.connect(socket_path)

    client_socket.send(b"Fecha y hora, por favor")
    respuesta = client_socket.recv(1024).decode()

    print("Cliente: Respuesta del servidor:")
    print(respuesta)

    client_socket.close()

if __name__ == "__main__":
    obtener_fecha_hora()

