class Bolos:
    def marcador(self, lanzamientos):
        puntuacion = 0
        for i in range(0, len(lanzamientos)):
            if type(lanzamientos[i]) == list:
                ronda = lanzamientos[i]
                if (i <= 9):
                    for bola in range(len(ronda)):
                        if (ronda[bola] == "/"):
                            tirada_anterior = ronda[bola-1]
                            siguiente_ronda = lanzamientos[i+1]
                            if (siguiente_ronda == "X"):
                                puntuacion += 20 - tirada_anterior
                            else:
                                puntuacion += 10 - tirada_anterior + siguiente_ronda[0]
                        else:
                            puntuacion += ronda[bola]
            elif(i <= 9 and lanzamientos[i] == "X"):
                siguiente_ronda = lanzamientos[i+1]
                if (siguiente_ronda == "X"):
                    siguiente_ronda2 = lanzamientos[i+2]
                    if (siguiente_ronda2 == "X"):
                        puntuacion += 30
                    else:
                        puntuacion += 20 + siguiente_ronda2[0]
                else:
                    if (siguiente_ronda[1] == "/"):
                        puntuacion += 20
                    else:
                        puntuacion += 10 + siguiente_ronda[0] + siguiente_ronda[1]
        return puntuacion

