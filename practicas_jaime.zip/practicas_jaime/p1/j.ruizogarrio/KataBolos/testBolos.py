import unittest
from bolos import *

bolos = Bolos()

class TestBolos(unittest.TestCase):
    def test_marcador_inicial(self):
        lanzamientos = ([0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(0, bolos.marcador(lanzamientos))

    def test_primer_lanzamiento(self):
        lanzamientos = ([5, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(5, bolos.marcador(lanzamientos))

    def test_varios_lanzamientos(self):
        lanzamientos = ([5, 3], [6, 0], [2, 0], [0, 4], [7, 0], [0, 2], [9, 0], [4, 0], [1, 0], [1, 0])
        self.assertEqual(44, bolos.marcador(lanzamientos))

    def test_spare_simple(self):
        lanzamientos = ([5, "/"], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(10, bolos.marcador(lanzamientos))

    def test_spare_completo(self):
        lanzamientos = ([5, "/"], [7, 1], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(25, bolos.marcador(lanzamientos))

    def test_spare_multiples(self):
        lanzamientos = ([5, "/"], [7, 1], [4, "/"], [4, 1], [2, "/"], [6, "/"], [2, 6], [0, 0], [0, 0], [0, 0])
        self.assertEqual(80, bolos.marcador(lanzamientos))

    def test_spare_seguidos(self):
        lanzamientos = ([5, "/"],[4, "/"], [4, 2], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(34, bolos.marcador(lanzamientos))

    def test_strike_basico(self):
        lanzamientos = ("X", [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(10, bolos.marcador(lanzamientos))

    def test_strike_completo(self):
        lanzamientos = ("X", [5, 4], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(28, bolos.marcador(lanzamientos))

    def test_varios_strikes(self):
        lanzamientos = ("X", [5, 4], "X", [6, 2], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(54, bolos.marcador(lanzamientos))

    def test_strike_mas_spare_simple(self):
        lanzamientos = ("X", [5, "/"], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(30, bolos.marcador(lanzamientos))

    def test_strike_mas_spare_complejo(self):
        lanzamientos = ("X", [5, "/"], [5, 4], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(44, bolos.marcador(lanzamientos))


    def test_spare_con_strike_simple(self):
        lanzamientos = ([3, "/"], "X", [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(30, bolos.marcador(lanzamientos))

    def test_spare_con_strike_complejo(self):
        lanzamientos = ([8, "/"], "X", [2, 4], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(42, bolos.marcador(lanzamientos))

    def test_strikes_seguidos_simple(self):
        lanzamientos = ("X", "X", [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(30, bolos.marcador(lanzamientos))

    def test_strikes_seguidos_complejo(self):
        lanzamientos = ("X", "X", [3, 6], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(51, bolos.marcador(lanzamientos))

    def test_strikes_seguidos_mas_spare_simple(self):
        lanzamientos = ("X", "X", [5, "/"], [0, 0], [0, 0],  [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(55, bolos.marcador(lanzamientos))

    def test_strikes_seguidos_mas_spare_completo(self):
        lanzamientos = ("X", "X", [5, "/"], [4, 1], [0, 0],  [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(64, bolos.marcador(lanzamientos))

    def test_strike_al_final_sin_puntos(self):
        lanzamientos = ([0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0,0], "X", [0,0])
        self.assertEqual(10, bolos.marcador(lanzamientos))

    def test_strike_al_final_con_puntos(self):
        lanzamientos = ([0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0,0], "X", [5,0])
        self.assertEqual(15, bolos.marcador(lanzamientos))

    def test_dos_strikes_al_final_sin_puntos(self):
        lanzamientos = ([0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], "X", "X", [0,0])
        self.assertEqual(30, bolos.marcador(lanzamientos))

    def test_dos_strikes_al_final_con_puntos(self):
        lanzamientos = ([0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], "X", "X", [4,1])
        self.assertEqual(39, bolos.marcador(lanzamientos))

    def test_dos_strikes_al_final_con_spare(self):
        lanzamientos = ([0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], "X", "X", [4,"/"])
        self.assertEqual(44, bolos.marcador(lanzamientos))

    def test_spare_con_strike_al_final_simple(self):
        lanzamientos = ([0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [4,"/"],  "X", [0,0])
        self.assertEqual(30, bolos.marcador(lanzamientos))

    def test_spare_con_strike_al_final_con_puntos(self):
        lanzamientos = ([0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [4,"/"],  "X", [2,3])
        self.assertEqual(35, bolos.marcador(lanzamientos))

    def test_ronda_perfecta(self):
        lanzamientos = ("X", "X", "X", "X", "X", "X", "X", "X", "X", "X", "X", "X")
        self.assertEqual(300, bolos.marcador(lanzamientos))

    def test_tiro_adicional_2_es_cero(self):
        lanzamientos = ([0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0,0], "X", "X", [0])
        self.assertEqual(20, bolos.marcador(lanzamientos))

    def test_tiro_adicional_2_puntua(self):
        lanzamientos = ([0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0,0], "X", "X", [5])
        self.assertEqual(25, bolos.marcador(lanzamientos))

    def test_spare_al_final_simple(self):
        lanzamientos = ([0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [3, "/"], [0])
        self.assertEqual(10, bolos.marcador(lanzamientos))

    def test_dos_spare_al_final_simple(self):
        lanzamientos = ([0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [4, "/"], [3, "/"], [0])
        self.assertEqual(23, bolos.marcador(lanzamientos))

    def test_spare_al_final_con_puntos(self):
        lanzamientos = ([0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0,0], [1, "/"], [5])
        self.assertEqual(15, bolos.marcador(lanzamientos))

    def test_strike_con_spare_al_final_con_strike(self):
        lanzamientos = ([0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], "X", [1, "/"], "X")
        self.assertEqual(40, bolos.marcador(lanzamientos))

    def test_spare_seguidos_con_strike_simple(self):
        lanzamientos = ([5, "/"],[4, "/"], "X", [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(44, bolos.marcador(lanzamientos))

    def test_spare_seguidos_con_strike_complejo(self):
        lanzamientos = ([5, "/"],[4, "/"], "X", [4, 1], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0])
        self.assertEqual(54, bolos.marcador(lanzamientos))


if __name__ == '__main__':
    unittest.main()
