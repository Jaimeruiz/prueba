import os

fifo_cliente = '/tmp/fifo_cliente'
fifo_servidor = '/tmp/fifo_servidor'

class Servidor:
    def __init__(self):
        if not os.path.exists(fifo_cliente):
            os.mkfifo(fifo_cliente)

        if not os.path.exists(fifo_servidor):
            os.mkfifo(fifo_servidor)

    def enviar_contenido_archivo(self):
        fifo_cliente_fd = os.open(fifo_cliente, os.O_RDONLY)
        archivo = os.read(fifo_cliente_fd, 100).decode()
        os.close(fifo_cliente_fd)

        try:
            with open(archivo, 'r') as f:
                contenido = f.read()
                respuesta = contenido.encode()
        except FileNotFoundError:
            respuesta = b"Error: Archivo no encontrado"

        fifo_servidor_fd = os.open(fifo_servidor, os.O_WRONLY)
        os.write(fifo_servidor_fd, respuesta)
        os.close(fifo_servidor_fd)


if __name__ == "__main__":
    servidor = Servidor()
    servidor.enviar_contenido_archivo()

