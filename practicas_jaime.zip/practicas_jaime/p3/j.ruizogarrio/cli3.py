import os

fifo_cliente = '/tmp/fifo_cliente'
fifo_servidor = '/tmp/fifo_servidor'

class Cliente:

    def __init__(self):
        if not os.path.exists(fifo_cliente):
            os.mkfifo(fifo_cliente)

        if not os.path.exists(fifo_servidor):
            os.mkfifo(fifo_servidor)

    def solicitar_archivo(self, archivo):
        print(f"Cliente: Solicitando archivo {archivo} al servidor...")
        fifo_cliente_fd = os.open(fifo_cliente, os.O_WRONLY)
        os.write(fifo_cliente_fd, archivo.encode(encoding='UTF-8', errors='strict'))
        os.close(fifo_cliente_fd)

        fifo_servidor_fd = os.open(fifo_servidor, os.O_RDONLY)
        respuesta = os.read(fifo_servidor_fd, 100)
        os.close(fifo_servidor_fd)

        print("Cliente: Respuesta del servidor:")
        print(respuesta.decode())


if __name__ == "__main__":
    cliente = Cliente()
    cliente.solicitar_archivo("archivo.txt")

