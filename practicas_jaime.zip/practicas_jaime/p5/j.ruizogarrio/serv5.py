import socket
import os

server_address = ('localhost', 12345)

def enviar_contenido_archivo():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind(server_address)

    print("Servidor: Esperando solicitudes de clientes...")

    while True:
        solicitud, client_address = server_socket.recvfrom(1024)
        archivo = solicitud.decode()

        try:
            with open(archivo, 'r') as f:
                contenido = f.read()
                respuesta = contenido.encode()
        except FileNotFoundError:
            respuesta = b"Error: Archivo no encontrado"

        server_socket.sendto(respuesta, client_address)

if __name__ == "__main__":
    enviar_contenido_archivo()

