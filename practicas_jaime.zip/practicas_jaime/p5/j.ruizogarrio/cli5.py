import socket

server_address = ('localhost', 12345)

def solicitar_archivo(archivo):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    solicitud = archivo.encode()
    client_socket.sendto(solicitud, server_address)

    respuesta, _ = client_socket.recvfrom(1024)
    print("Cliente: Respuesta del servidor:")
    print(respuesta.decode())

    client_socket.close()

if __name__ == "__main__":
    archivo_solicitado = "archivi1.txt"
    solicitar_archivo(archivo_solicitado)

