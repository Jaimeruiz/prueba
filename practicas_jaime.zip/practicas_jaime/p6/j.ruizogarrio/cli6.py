import socket

server_address = ('localhost', 12345)

def obtener_fecha_hora():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(server_address)

    client_socket.send(b"Fecha y hora, por favor")
    respuesta = client_socket.recv(1024).decode()

    print("Cliente: Respuesta del servidor:")
    print(respuesta)

    client_socket.close()

if __name__ == "__main__":
    obtener_fecha_hora()

