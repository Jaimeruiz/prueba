import socket
import datetime

server_address = ('localhost', 12345)

def responder_fecha_hora():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(server_address)
    server_socket.listen(1)

    print("Servidor: Esperando conexión del cliente...")

    while True:
        conn, addr = server_socket.accept()
        print("Servidor: Cliente conectado:", addr)

        solicitud = conn.recv(1024).decode()

        if solicitud == "Fecha y hora, por favor":
            ahora = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            conn.send(ahora.encode())

        conn.close()

if __name__ == "__main__":
    responder_fecha_hora()

