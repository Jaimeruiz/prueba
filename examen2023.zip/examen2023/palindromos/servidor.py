import socket

import gestor

server_addr = ('localhost', 16073)
g = gestor
def servidor():
    socket_servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    socket_servidor.bind(server_addr)
    socket_servidor.listen(5)
    print('Servidor esperando solicitudes de clientes... \n')

    while True:
        conn, cliente_addr = socket_servidor.accept()
        print('Cliente conectado: ', cliente_addr)
        peticion = conn.recv(1024)
        solicitud = g.decodificar(peticion)
        if solicitud == 'palabra':
            peticion2 = conn.recv(1024)
            palabra = g.decodificar(peticion2)
            if g.invertir(palabra):
                respuesta = g.codificar('La palabra es un palindromo')
            else:
                respuesta = g.codificar('La palabra no es un palindromo')
        elif solicitud == 'numero':
            peticion2 = conn.recv(1024)
            numero = g.decodificar(peticion2)
            if g.invertir(numero):
                respuesta = g.codificar('El numero es capicua')
            else:
                respuesta = g.codificar('La numero no es capicua')
        else:
            respuesta = g.codificar('ERROR')

        conn.send(respuesta)
        conn.close()

if __name__ == '__main__':
    servidor()
