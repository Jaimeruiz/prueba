import socket
import gestor

puerto = int(input('Introduzca el puerto al que desea conectarse: '))
server_addr = ('localhost', puerto)
g = gestor
def cliente():
    socket_cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    socket_cliente.connect(server_addr)

    print('Elija una de las siguientes opciones: \n')
    print('1. Comprobar palindromo \n')
    print('2. Comprobar capicua \n')
    print('3. Apagar servidor \n')
    opcion = int(input('Opcion: '))

    if opcion == 1:
        peticion = g.codificar('palabra')
        socket_cliente.send(peticion)
        peticion2 = str(input('Introduce la palabra a comprobar: '))
        palabra = g.codificar(peticion2)
        socket_cliente.send(palabra)
    elif opcion == 2:
        peticion = g.codificar('numero')
        socket_cliente.send(peticion)
        peticion2 = str(input('Introduce el numero a comprobar: '))
        numero = g.codificar(peticion2)
        socket_cliente.send(numero)

    respuesta = socket_cliente.recv(1024)
    respuesta_def = g.decodificar(respuesta)
    print('Servidor responde a la peticion: \n')
    print(respuesta_def)


if __name__ == '__main__':
    cliente()
