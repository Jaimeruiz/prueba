
import gestor
import unittest


class TestServidor(unittest.TestCase):

    def test_something(self):
        self.assertEqual(True, True)

    def test_codificar_vacio(self):
        texto = ""
        resultado = gestor.codificar(texto)
        self.assertEqual(resultado, b'')
    
    
    def test_codificar_palabra(self):
        mensaje = 'hola'
        mensaje_cod = gestor.codificar(mensaje)
        self.assertEqual(mensaje_cod, b'hola')

    def test_codificar_numero(self):
        mensaje = '12345'
        mensaje_cod = gestor.codificar(mensaje)
        self.assertEqual(mensaje_cod, b'12345')

    def test_decodificar_vacio(self):
        mensaje_codificado = b''
        resultado = gestor.decodificar(mensaje_codificado)
        self.assertEqual(resultado, '')

    def test_decodificar_palabra(self):
        mensaje_cod = b'adios'
        mensaje = gestor.decodificar(mensaje_cod)
        self.assertEqual(mensaje, 'adios')

    def test_decodificar_numero(self):
        mensaje_cod = b'12345'
        mensaje = gestor.decodificar(mensaje_cod)
        self.assertEqual(mensaje , '12345')

    def test_invertir_letras(self):
        palabra_palindromo = "a"
        resultado = gestor.invertir(palabra_palindromo)
        self.assertTrue(resultado)

    def test_invertir_no_palindromo(self):
        palabra_no_palindromo = "hola"
        resultado = gestor.invertir(palabra_no_palindromo)
        self.assertFalse(resultado)

    def test_invertir_palindromo_largo(self):
        palabra_palindromo = "reconocer"
        resultado = gestor.invertir(palabra_palindromo)
        self.assertTrue(resultado)

    def test_invertir_capicua_sencillo(self):
        palabra_no_palindromo = "1"
        resultado = gestor.invertir(palabra_no_palindromo)
        self.assertTrue(resultado)

    def test_invertir_no_capicua(self):
        palabra_palindromo = "123"
        resultado = gestor.invertir(palabra_palindromo)
        self.assertFalse(resultado)

    def test_invertir_capicua_largo(self):
        palabra_no_palindromo = "1234567890987654321"
        resultado = gestor.invertir(palabra_no_palindromo)
        self.assertTrue(resultado)

if __name__ == '__main__':
    unittest.main()
