
import gestor
import unittest


class TestServidor(unittest.TestCase):

    def test_something(self):
        self.assertEqual(True, True)

    def test_codificar_vacio(self):
        texto = ""
        resultado = gestor.codificar(texto)
        self.assertEqual(resultado, b'')
    
    
    def test_codificar_palabra(self):
        mensaje = 'hola'
        mensaje_cod = gestor.codificar(mensaje)
        self.assertEqual(mensaje_cod, b'hola')

    def test_codificar_numero(self):
        mensaje = '12345'
        mensaje_cod = gestor.codificar(mensaje)
        self.assertEqual(mensaje_cod, b'12345')

    def test_decodificar_vacio(self):
        mensaje_codificado = b''
        resultado = gestor.decodificar(mensaje_codificado)
        self.assertEqual(resultado, '')

    def test_decodificar_palabra(self):
        mensaje_cod = b'adios'
        mensaje = gestor.decodificar(mensaje_cod)
        self.assertEqual(mensaje, 'adios')

    def test_decodificar_numero(self):
        mensaje_cod = b'12345'
        mensaje = gestor.decodificar(mensaje_cod)
        self.assertEqual(mensaje , '12345')

    def test_contar_caracter(self):
        documento = "jaime"
        apariciones = gestor.contador(documento, "j")
        self.assertEqual(1, apariciones)

    def test_contar_es_cero(self):
        documento = "laura"
        apariciones = gestor.contador(documento, "e")
        self.assertEqual(0, apariciones)
    
    def test_contar_caracteres(self):
        documento = "Hola buenos días, ¿Qué tal todo?"
        apariciones = gestor.contador(documento, "o")
        self.assertEqual(4, apariciones)

    def test_contar_palabra(self):
        documento = "hola ¿Qué tal estas?"
        apariciones = gestor.contador(documento, "hola")
        self.assertEqual(1, apariciones)

    def test_contar_palabra_es_cero(self):
        documento = "Hola buenos días"
        apariciones = gestor.contador(documento, "que")
        self.assertEqual(0, apariciones)

    def test_contar_palabras(self):
        documento = "hola hola hola. ¿Qué tal todo?"
        apariciones = gestor.contador(documento, "hola")
        self.assertEqual(3, apariciones)

    def test_aparece_frase(self):
        documento = "Hola buenos días, ¿Que tal todo?.  Todo bien, ¿Que tal usted?"
        apariciones = gestor.contador(documento, "Que tal")
        self.assertEqual(2, apariciones)

    def test_contar_simbolos(self):
        documento = "hola hola hola. ¿Qué tal todo?. Yo estoy bien. Gracias por preguntar. Hasta pronto."
        apariciones = gestor.contador(documento, ".")
        self.assertEqual(5, apariciones)


if __name__ == '__main__':
    unittest.main()
