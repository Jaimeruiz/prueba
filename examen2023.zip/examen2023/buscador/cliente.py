import socket
import gestor

puerto = int(input('Introduzca el puerto al que desea conectarse: '))
server_addr = ('localhost', puerto)
g = gestor
def cliente():
    socket_cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    socket_cliente.connect(server_addr)

    archivo = str(input('Archivo: '))
    sol_archivo = g.codificar(archivo)
    socket_cliente.send(sol_archivo)

    buscar = str(input('Introduzca el elemento a buscar: '))
    sol_buscar = g.codificar(buscar)
    socket_cliente.send(sol_buscar)


    respuesta = socket_cliente.recv(1024)
    respuesta_def = g.decodificar(respuesta)
    print('Servidor responde a la peticion: \n')
    print(f'El texto "{buscar}" aparece en el archivo "{archivo}" {respuesta_def} veces')


if __name__ == '__main__':
    cliente()
