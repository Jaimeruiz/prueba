
def codificar(texto):
    mensaje_cod = texto.encode('UTF-8')
    return mensaje_cod

def decodificar(mensaje_cod):
    mensaje_decod = mensaje_cod.decode('UTF-8')
    return mensaje_decod

def contador(fichero, texto):
    numero = fichero.count(texto)
    return numero
