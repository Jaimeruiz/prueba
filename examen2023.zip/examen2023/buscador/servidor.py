import socket

import gestor

server_addr = ('localhost', 16073)
g = gestor
def servidor():
    socket_servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    socket_servidor.bind(server_addr)
    socket_servidor.listen(5)
    print('Servidor esperando solicitudes de clientes... \n')

    while True:
        conn, cliente_addr = socket_servidor.accept()
        print('Cliente conectado: ', cliente_addr)
        peticion = conn.recv(1024)
        archivo = g.decodificar(peticion)
        try:
            with open(archivo, 'r') as file:
                contenido = file.read()
                texto = conn.recv(1024)
                texto_buscar = g.decodificar(texto)
                contador = g.contador(contenido, texto_buscar)
                respuesta = g.codificar(str(contador))
        except FileNotFoundError:
                respuesta = g.codificar('ERROR')

        conn.send(respuesta)
        conn.close()

if __name__ == '__main__':
    try:
        servidor()
    except KeyboardInterrupt:
        print('\n El servidor se apago correctamente')
