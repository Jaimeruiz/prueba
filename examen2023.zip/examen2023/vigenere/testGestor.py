
import gestor
import os
import unittest


class TestServidor(unittest.TestCase):

    def test_something(self):
        self.assertEqual(True, True)

    def test_codificar_palabra(self):
        mensaje = 'hola'
        mensaje_cod = gestor.codificar(mensaje)
        self.assertEqual(mensaje_cod, b'hola')

    def test_codificar_numero(self):
        mensaje = '12345'
        mensaje_cod = gestor.codificar(mensaje)
        self.assertEqual(mensaje_cod, b'12345')

    def test_decodificar_palabra(self):
        mensaje_cod = b'adios'
        mensaje = gestor.decodificar(mensaje_cod)
        self.assertEqual(mensaje, 'adios')

    def test_decodificar_numero(self):
        mensaje_cod = b'12345'
        mensaje = gestor.decodificar(mensaje_cod)
        self.assertEqual(mensaje , '12345')

    def test_cifrar_vigenere(self):
        texto = "Hola, esto es una prueba."
        clave = "secreta"
        texto_cifrado = gestor.cifrar_vigenere(texto, clave)
        self.assertEqual(texto_cifrado, "Zsnr, eKxq iL Mrc tKuwfc.")

    def test_descifrar_vigenere(self):
        texto_cifrado = "Zsnr, eKxq iL Mrc tKuwfc."
        clave = "secreta"
        texto_descifrado = gestor.descifrar_vigenere(texto_cifrado, clave)
        self.assertEqual(texto_descifrado, "Hola, esto es una prueba.")

    def test_cifrar_archivo_vigenere(self):
        nombre_archivo = "test_archivo.txt"
        clave = "secreta"

        # Crear un archivo de prueba
        with open(nombre_archivo, 'w') as archivo:
            archivo.write("Este es un mensaje de prueba.")

        # Cifrar el archivo
        gestor.cifrar_archivo_vigenere(nombre_archivo, clave)

        # Verificar si el archivo cifrado existe
        nombre_archivo_cifrado = f"{nombre_archivo.split('.')[0]}_cifrado.txt"
        self.assertTrue(os.path.exists(nombre_archivo_cifrado))

    def test_descifrar_archivo_vigenere(self):
        nombre_archivo_cifrado = "test_archivo_cifrado.txt"
        clave = "secreta"

        # Crear un archivo de prueba cifrado
        with open(nombre_archivo_cifrado, 'w') as archivo_cifrado:
            archivo_cifrado.write("Zsnr, eKxq iL Mrc tKuwfc.")

        # Descifrar el archivo
        gestor.descifrar_archivo_vigenere(nombre_archivo_cifrado, clave)

        # Verificar si el archivo descifrado existe
        nombre_archivo_descifrado = f"{nombre_archivo_cifrado.split('_cifrado.')[0]}_descifrado.txt"
        self.assertTrue(os.path.exists(nombre_archivo_descifrado))

    def test_cifrar_vigenere_longitud_clave_menor_texto(self):
        texto = "Hola, esto es una prueba."
        clave = "secreta"
        texto_cifrado = gestor.cifrar_vigenere(texto, clave)
        self.assertEqual(texto_cifrado, "Zsnr, eKxq iL Mrc tKuwfc.")

    def test_cifrar_vigenere_longitud_clave_mayor_texto(self):
        texto = "Hola, esto es una prueba."
        clave = "claveextralarga"
        texto_cifrado = gestor.cifrar_vigenere(texto, clave)
        self.assertEqual(texto_cifrado, "Jzlv, BLKo eJ upl KvyBur.")

    def test_descifrar_vigenere_longitud_clave_menor_texto(self):
        texto_cifrado = "Zsnr, eKxq iL Mrc tKuwfc."
        clave = "secreta"
        texto_descifrado = gestor.descifrar_vigenere(texto_cifrado, clave)
        self.assertEqual(texto_descifrado, "Hola, esto es una prueba.")

    def test_descifrar_vigenere_longitud_clave_mayor_texto(self):
        texto_cifrado = "Jzlv, BLKo eJ upl KvyBur."
        clave = "claveextralarga"
        texto_descifrado = gestor.descifrar_vigenere(texto_cifrado, clave)
        self.assertEqual(texto_descifrado, "Hola, esto es una prueba.")



if __name__ == '__main__':
    unittest.main()


