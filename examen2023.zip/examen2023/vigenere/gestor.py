import datetime
def codificar(texto):
    mensaje_cod = texto.encode('UTF-8')
    return mensaje_cod

def decodificar(mensaje_cod):
    mensaje_decod = mensaje_cod.decode('UTF-8')
    return mensaje_decod


def cifrar_vigenere(texto, clave):
    caracteres = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    texto_cifrado = ''
    clave_extendida = clave * (len(texto) // len(clave)) + clave[:len(texto) % len(clave)]

    for i in range(len(texto)):
        if texto[i] in caracteres:
            index_texto = caracteres.index(texto[i])
            index_clave = caracteres.index(clave_extendida[i])
            index_cifrado = (index_texto + index_clave) % len(caracteres)
            texto_cifrado += caracteres[index_cifrado]
        else:
            texto_cifrado += texto[i]

    return texto_cifrado


def descifrar_vigenere(texto_cifrado, clave):
    caracteres = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    texto_descifrado = ''
    clave_extendida = clave * (len(texto_cifrado) // len(clave)) + clave[:len(texto_cifrado) % len(clave)]

    for i in range(len(texto_cifrado)):
        if texto_cifrado[i] in caracteres:
            index_cifrado = caracteres.index(texto_cifrado[i])
            index_clave = caracteres.index(clave_extendida[i])
            index_descifrado = (index_cifrado - index_clave) % len(caracteres)
            texto_descifrado += caracteres[index_descifrado]
        else:
            texto_descifrado += texto_cifrado[i]

    return texto_descifrado


def cifrar_archivo_vigenere(nombre_archivo, clave):
    try:
        with open(nombre_archivo, 'r') as archivo:
            contenido = archivo.read()
            contenido_cifrado = cifrar_vigenere(contenido, clave)

        nombre_archivo_cifrado = f"{nombre_archivo.split('.')[0]}_cifrado.txt"

        with open(nombre_archivo_cifrado, 'w') as archivo_cifrado:
            archivo_cifrado.write(contenido_cifrado)

        print(f"Archivo cifrado guardado como '{nombre_archivo_cifrado}'.")

    except FileNotFoundError:
        print(f"No se encontró el archivo '{nombre_archivo}'.")


def descifrar_archivo_vigenere(nombre_archivo_cifrado, clave):
    try:
        with open(nombre_archivo_cifrado, 'r') as archivo_cifrado:
            contenido_cifrado = archivo_cifrado.read()
            contenido_descifrado = descifrar_vigenere(contenido_cifrado, clave)

        nombre_archivo_descifrado = f"{nombre_archivo_cifrado.split('_cifrado.')[0]}_descifrado.txt"

        with open(nombre_archivo_descifrado, 'w') as archivo_descifrado:
            archivo_descifrado.write(contenido_descifrado)

        print(f"Archivo descifrado guardado como '{nombre_archivo_descifrado}'.")

    except FileNotFoundError:
        print(f"No se encontró el archivo '{nombre_archivo_cifrado}'.")


