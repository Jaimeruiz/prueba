import socket
import gestor

puerto = int(input('Introduce el numero de puerto: '))
server_addr = ('localhost', puerto)
g = gestor
def cliente():
    socket_cliente = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    print('Elije la accion que quieres llevar a cabo: \n')
    print('1. Cifrar una cadena \n')
    print('2. Cifrar un archivo \n')
    print('3. Descifrar una cadena \n')
    print('4. Descifrar un archivo \n')
    opcion = int(input('Opcion: '))

    if opcion == 1:
        peticion = 'cifrar cadena'
        solicitud = g.codificar(peticion)
        socket_cliente.sendto(solicitud, server_addr)
        frase = str(input('Introduce la cadena a cifrar: '))
        cadena = g.codificar(frase)
        socket_cliente.sendto(cadena, server_addr)
        texto = str(input('Introduce la clave de cifrado: '))
        clave = g.codificar(texto)
        socket_cliente.sendto(clave, server_addr)
    elif opcion == 2:
        peticion = 'cifrar archivo'
        solicitud = g.codificar(peticion)
        socket_cliente.sendto(solicitud, server_addr)
        archivo = str(input('Introduce el archivo a cifrar: '))
        file = g.codificar(archivo)
        socket_cliente.sendto(file, server_addr)
        texto = str(input('Introduce la clave de cifrado: '))
        clave = g.codificar(texto)
        socket_cliente.sendto(clave, server_addr)
    elif opcion == 3:
        peticion = 'descifrar cadena'
        solicitud = g.codificar(peticion)
        socket_cliente.sendto(solicitud, server_addr)
        frase = str(input('Introduce la cadena a descifrar: '))
        cadena = g.codificar(frase)
        socket_cliente.sendto(cadena, server_addr)
        texto = str(input('Introduce la clave de descifrado: '))
        clave = g.codificar(texto)
        socket_cliente.sendto(clave, server_addr)
    elif opcion == 4:
        peticion = 'descifrar archivo'
        solicitud = g.codificar(peticion)
        socket_cliente.sendto(solicitud, server_addr)
        archivo = str(input('Introduce el archivo a descifrar: '))
        file = g.codificar(archivo)
        socket_cliente.sendto(file, server_addr)
        texto = str(input('Introduce la clave de descifrado: '))
        clave = g.codificar(texto)
        socket_cliente.sendto(clave, server_addr)

    respuesta, _ = socket_cliente.recvfrom(1024)
    respuesta_def = g.decodificar(respuesta)
    print('Servidor Responde: \n')
    print(respuesta_def)

    socket_cliente.close()

if __name__ == '__main__':
    cliente()
