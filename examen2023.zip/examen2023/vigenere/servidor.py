import socket
import gestor
server_addr = ('localhost', 16073)
g = gestor
def servidor():
    socket_sevidor = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    socket_sevidor.bind(server_addr)
    print("Servidor: Esperando solicitudes de clientes...")

    while True:
        peticion, cliente_addr = socket_sevidor.recvfrom(1024)
        solicitud1 = g.decodificar(peticion)

        if solicitud1 == 'cifrar cadena':
            peticion2, cliente_addr = socket_sevidor.recvfrom(1024)
            cadena = g.decodificar(peticion2)
            peticion3,cliente_addr = socket_sevidor.recvfrom(1024)
            clave = g.decodificar(peticion3)
            cifrado = g.cifrar_vigenere(cadena,clave)
            respuesta = g.codificar(cifrado)
            socket_sevidor.sendto(respuesta, cliente_addr)
        elif solicitud1 == 'descifrar cadena':
            peticion2, cliente_addr = socket_sevidor.recvfrom(1024)
            cadena = g.decodificar(peticion2)
            peticion3, cliente_addr = socket_sevidor.recvfrom(1024)
            clave = g.decodificar(peticion3)
            descifrado = g.descifrar_vigenere(cadena,clave)
            respuesta = g.codificar(descifrado)
            socket_sevidor.sendto(respuesta, cliente_addr)
        elif solicitud1 == 'cifrar archivo':
            peticion2, cliente_addr = socket_sevidor.recvfrom(1024)
            archivo = g.decodificar(peticion2)
            peticion3, cliente_addr = socket_sevidor.recvfrom(1024)
            clave = g.decodificar(peticion3)
            g.cifrar_archivo_vigenere(archivo, clave)
            respuesta = g.codificar('Archivo cifrado con exito, compruebe su directorio')
            socket_sevidor.sendto(respuesta, cliente_addr)
        elif solicitud1 == 'descifrar archivo':
            peticion2, cliente_addr = socket_sevidor.recvfrom(1024)
            archivo = g.decodificar(peticion2)
            peticion3, cliente_addr = socket_sevidor.recvfrom(1024)
            clave = g.decodificar(peticion3)
            g.descifrar_archivo_vigenere(archivo, clave)
            respuesta = g.codificar('Archivo descifrado con exito, compruebe su directorio')
            socket_sevidor.sendto(respuesta, cliente_addr)

if __name__ == '__main__':
    servidor()
