import socket

import gestor

server_addr = ('localhost', 16073)
g = gestor
def servidor():
    socket_servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    socket_servidor.bind(server_addr)
    socket_servidor.listen(5)
    print('Servidor esperando solicitudes de clientes... \n')

    while True:
        conn, cliente_addr = socket_servidor.accept()
        print('Cliente conectado: ', cliente_addr)
        peticion1 = conn.recv(1024)
        letra = g.decodificar(peticion1)
        frase = letra.split(':')
        if len(frase) > 1:
            contador = frase[1].count(letra[0])
            respuesta = g.codificar(str(contador))
            conn.send(respuesta)
            conn.close()

if __name__ == '__main__':
    servidor()
