import socket
import gestor


g = gestor

def servidor():
    socket_servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    socket_servidor.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    direccionServidor = ('localhost', 19830)

    socket_servidor.bind(direccionServidor)
    socket_servidor.listen(5)

    while True:
        nuevo_socket, nueva_Direccion = socket_servidor.accept()

        limite = int(input("\nLimite: "))
        nuevo_socket.send(g.codificar(str(limite)))

        g.sumar_numeros(nuevo_socket, limite)


if __name__ == '__main__':
    try:
        servidor()
    except KeyboardInterrupt:
        print("\nEL SERVIDOR SE HA APAGADO CORRECTAMENTE")

