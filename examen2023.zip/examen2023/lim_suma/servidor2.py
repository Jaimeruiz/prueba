import socket, gestor
g = gestor

def servidor():

    socket_servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    socket_servidor.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    direccionServidor = ('localhost', 19830)

    socket_servidor.bind(direccionServidor)

    socket_servidor.listen(5)

    while True:

        nuevo_socket, nueva_Direccion = socket_servidor.accept()

        limite = int(input("\nLimite: "))
        nuevo_socket.send(g.codificar(str(limite)))

        suma=0

        while suma < limite:
            recibe_numero = nuevo_socket.recv(1024)
            numero = int(g.decodificar(recibe_numero))

            suma = suma + numero

            if suma < limite:
                nuevo_socket.send(g.codificar(str(suma)))
                print("Suma = ", suma)
            else:
                nuevo_socket.send(g.codificar("FIN"))
                break


if __name__ == '__main__':
    try:
        servidor()
    except KeyboardInterrupt:
        print("\n EL SERVIDOR SE HA APAGADO CORRECTAMENTE")

