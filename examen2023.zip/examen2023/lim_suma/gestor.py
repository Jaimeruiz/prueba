def codificar(mensaje):
    mensaje_cod = mensaje.encode("UTF-8")
    return mensaje_cod

def decodificar(mensaje_cod):
    mensaje_decode = mensaje_cod.decode("UTF-8")
    return mensaje_decode

def sumar_numeros(nuevo_socket, limite):
    suma = 0

    while suma < limite:
        recibe_numero = nuevo_socket.recv(1024)
        numero = int(decodificar(recibe_numero))

        suma = suma + numero

        if suma < limite:
            nuevo_socket.send(codificar(str(suma)))
            print("Suma =", suma)
        else:
            nuevo_socket.send(codificar("FIN"))
            break
