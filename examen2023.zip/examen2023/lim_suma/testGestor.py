
import gestor
import unittest
from unittest.mock import patch
g = gestor

class TestServidor(unittest.TestCase):

    def test_something(self):
        self.assertEqual(True, True)

    def test_codificar_palabra(self):
        mensaje = 'hola'
        mensaje_cod = gestor.codificar(mensaje)
        self.assertEqual(mensaje_cod, b'hola')

    def test_codificar_numero(self):
        mensaje = '12345'
        mensaje_cod = gestor.codificar(mensaje)
        self.assertEqual(mensaje_cod, b'12345')

    def test_decodificar_palabra(self):
        mensaje_cod = b'adios'
        mensaje = gestor.decodificar(mensaje_cod)
        self.assertEqual(mensaje, 'adios')

    def test_decodificar_numero(self):
        mensaje_cod = b'12345'
        mensaje = gestor.decodificar(mensaje_cod)
        self.assertEqual(mensaje , '12345')

    def test_sumar_numeros(self):
        # Mock del socket
        mock_socket = unittest.mock.Mock()

        # Datos de prueba
        limite = 10
        numeros = [1, 2, 3, 4]

        # Llamadas esperadas al socket
        mock_socket.recv.side_effect = [gestor.codificar(str(num)) for num in numeros] + [gestor.codificar("FIN")]
        mock_socket.send.side_effect = None

        # Llamada a la función a probar
        g.sumar_numeros(mock_socket, limite)

        # Comprobación de las llamadas al socket
        expected_recv_calls = [unittest.mock.call(1024)] * (len(numeros) + 1)
        expected_send_calls = [unittest.mock.call(gestor.codificar(str(sum(numeros[:i])))) for i in
                               range(1, len(numeros) + 1)] + [unittest.mock.call(gestor.codificar("FIN"))]

        self.assertEqual(mock_socket.recv.call_args_list, expected_recv_calls)
        self.assertEqual(mock_socket.send.call_args_list, expected_send_calls)

    def test_sumar_numeros_limite_cero(self):
        # Mock del socket
        mock_socket = unittest.mock.Mock()

        # Datos de prueba
        limite = 0

        # Llamada a la función a probar
        g.sumar_numeros(mock_socket, limite)

        # Comprobación de las llamadas al socket
        expected_recv_calls = [unittest.mock.call(1024)]
        expected_send_calls = [unittest.mock.call(gestor.codificar("FIN"))]

        self.assertEqual(mock_socket.recv.call_args_list, expected_recv_calls)
        self.assertEqual(mock_socket.send.call_args_list, expected_send_calls)

    def test_sumar_numeros_un_solo_numero(self):
        # Mock del socket
        mock_socket = unittest.mock.Mock()

        # Datos de prueba
        limite = 5
        numeros = [5]

        # Llamadas esperadas al socket
        mock_socket.recv.side_effect = [gestor.codificar(str(num)) for num in numeros] + [gestor.codificar("FIN")]
        mock_socket.send.side_effect = None

        # Llamada a la función a probar
        g.sumar_numeros(mock_socket, limite)

        # Comprobación de las llamadas al socket
        expected_recv_calls = [unittest.mock.call(1024)] * (len(numeros) + 1)
        expected_send_calls = [unittest.mock.call(gestor.codificar(str(sum(numeros[:i])))) for i in
                               range(1, len(numeros) + 1)] + [unittest.mock.call(gestor.codificar("FIN"))]

        self.assertEqual(mock_socket.recv.call_args_list, expected_recv_calls)
        self.assertEqual(mock_socket.send.call_args_list, expected_send_calls)

if __name__ == '__main__':
    unittest.main()
