import socket, sys, gestor

g = gestor

def cliente():
    puerto = int(input("Escriba el puerto de escucha del servidor:\n"))
    direccion_socket = ('0.0.0.0', puerto)

    socket_cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        socket_cliente.connect(direccion_socket)
        print('Conexión establecida con el servidor\n')
    except:
        print('Error en la conexión\n')
        sys.exit(0)

    limite = socket_cliente.recv(1024)
    print("El limite es: {}".format(g.decodificar(limite)))

    while True:
        numero = input('Introduzca un numero\n')
        socket_cliente.send(g.codificar(numero))

        lectura_aviso = socket_cliente.recv(1024)
        aviso = g.decodificar(lectura_aviso)
        if aviso == "FIN":
            print(aviso)
            break

    socket_cliente.close()

if __name__ == '__main__':
    cliente()
