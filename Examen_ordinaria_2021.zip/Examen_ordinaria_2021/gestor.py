def codificar(mensaje):
	mensaje_cod = mensaje.encode("UTF-8")
	return mensaje_cod

def decodificar(mensaje_cod):
	mensaje_decode = mensaje_cod.decode("UTF-8")
	return mensaje_decode

def contador(fichero, texto):
	numero = fichero.count(texto)
	return numero