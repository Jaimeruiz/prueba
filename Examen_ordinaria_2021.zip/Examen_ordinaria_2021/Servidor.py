import socket, sys, gestor
g = gestor

def servidor():

    direccion = ('0.0.0.0', 16012)

    socket_servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    socket_servidor.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    socket_servidor.bind(direccion)
    socket_servidor.listen(5)

    print("Servidor esperando ...")

    while True:

        nuevo_socket, direccion_cliente = socket_servidor.accept()
        print("Petición atendida al cliente: ", direccion_cliente)

        texto = nuevo_socket.recv(1024)
        texto = g.decodificar(texto)

        lista = texto.split(":")

        if len(lista) == 1:
            nuevo_socket.send(g.codificar("ERROR")) #Si la longitud de la lista es 1 quiere decir que no se ha separado la frase enviada por el cliente con un espacio
            nuevo_socket.close()
        else:
            caracteres = lista[0]
            caracter = caracteres.split(",")
            for c in caracter:
                frase = lista[1]
                letras = list(frase)

                for i in letras:
                    resultado = g.contador(frase, i)

                mensaje = "{}:{}".format(c, resultado)
                print(mensaje)
                nuevo_socket.send(g.codificar(mensaje))

                if not c == caracter[-1]:
                    nuevo_socket.send(g.codificar(","))

            nuevo_socket.close()


try:
    servidor()
except KeyboardInterrupt:
    print("El servidor se ha apagado correctamente")