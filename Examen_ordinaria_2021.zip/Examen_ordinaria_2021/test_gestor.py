import unittest, gestor

class TestServidor(unittest.TestCase):

    def test_something(self):
        self.assertEqual(True, True)

    def test_codificar_palabra(self):
        mensaje = 'hola'
        mensaje_cod = gestor.codificar(mensaje)
        self.assertEqual(mensaje_cod, b'hola')

    def test_codificar_complicado(self):
        mensaje = "2. prueba con hola"
        mensaje_cod = gestor.codificar(mensaje)
        self.assertEqual(mensaje_cod, b'2. prueba con hola')

    def test_decodificar_palabra(self):
        mensaje_cod = b'hola'
        mensaje = gestor.decodificar(mensaje_cod)
        self.assertEqual(mensaje, "hola")

    def test_decodificar_complicado(self):
        mensaje_cod = b'12345 hola'
        mensaje = gestor.decodificar(mensaje_cod)
        self.assertEqual(mensaje , "12345 hola")

    def test_contar_caracteres(self):
        documento = "Hola buenos días, ¿Qué tal todo?"
        apariciones = gestor.contador(documento, "o")
        self.assertEqual(4, apariciones)

    def test_contar_caracteres_2(self):
        documento = "Hola hola hola hola hola hola"
        apariciones = gestor.contador(documento, "l")
        self.assertEqual(6, apariciones)

if __name__ == '__main__':
    unittest.main()


