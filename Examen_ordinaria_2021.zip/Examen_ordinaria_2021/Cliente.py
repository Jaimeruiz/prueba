import socket, sys, gestor
g = gestor

def cliente():
	puerto = int(input("Escriba el puerto de escucha del servidor:\n"))
	direccion_socket = ('0.0.0.0', puerto)

	socket_cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

	try:
		socket_cliente.connect(direccion_socket)
		print('Conexión establecida con el servidor\n')
	except:
		print('Error en la conexión\n')
		sys.exit(0)

	print("Inserte el caracter que desea buscar y a continuación la frase en la que desea buscar")
	print("Un ejemplo de consulta sería: ")
	print("m:Combinaciones momentáneas de palabras")
	print("En este caso el servidor nos devolverá --> m:3\n")

	frase = input("Haga ahora su consulta --> ")
	socket_cliente.send(g.codificar(frase))
	
	while True:
		respuesta = socket_cliente.recv(1024)
		respuesta = g.decodificar(respuesta)
		print(respuesta)
		if not respuesta:
			break
			
if __name__ == '__main__':
	try:
		cliente()
	except KeyboardInterrupt:
		print("\n Ha salido de la aplicación")